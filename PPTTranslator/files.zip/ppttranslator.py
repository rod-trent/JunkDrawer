import streamlit as st
import os
from pptx import Presentation
from openai import OpenAI
from dotenv import load_dotenv
import tempfile
from io import BytesIO

# Load environment variables
load_dotenv()

# Initialize xAI client
@st.cache_resource
def get_xai_client():
    api_key = os.getenv("XAI_API_KEY")
    if not api_key:
        st.error("XAI_API_KEY not found in .env file")
        return None
    return OpenAI(
        api_key=api_key,
        base_url="https://api.x.ai/v1"
    )

def translate_text(client, text, target_language, source_language="auto-detect"):
    """Translate text using xAI's API"""
    if not text or not text.strip():
        return text
    
    try:
        prompt = f"""Translate the following text from {source_language} to {target_language}. 
Only provide the translation without any explanations or additional text.

Text to translate:
{text}"""

        response = client.chat.completions.create(
            model="grok-3",
            messages=[
                {"role": "system", "content": "You are a professional translator. Provide only the translation without any explanations."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )
        
        return response.choices[0].message.content.strip()
    except Exception as e:
        st.error(f"Translation error: {str(e)}")
        return text

def translate_presentation(prs, client, target_language, source_language, progress_bar):
    """Translate all text in a PowerPoint presentation"""
    total_shapes = sum(len(slide.shapes) for slide in prs.slides)
    processed = 0
    
    for slide in prs.slides:
        for shape in slide.shapes:
            # Translate text in shapes
            if hasattr(shape, "text") and shape.text:
                if hasattr(shape, "text_frame"):
                    for paragraph in shape.text_frame.paragraphs:
                        for run in paragraph.runs:
                            if run.text.strip():
                                run.text = translate_text(client, run.text, target_language, source_language)
            
            # Translate text in tables
            if shape.has_table:
                for row in shape.table.rows:
                    for cell in row.cells:
                        if cell.text.strip():
                            cell.text = translate_text(client, cell.text, target_language, source_language)
            
            processed += 1
            progress_bar.progress(processed / total_shapes)
    
    return prs

def main():
    st.set_page_config(
        page_title="PowerPoint Translator",
        page_icon="🌐",
        layout="wide"
    )
    
    st.title("🌐 PowerPoint Translator")
    st.markdown("Translate your PowerPoint presentations using xAI's Grok API")
    
    # Initialize xAI client
    client = get_xai_client()
    if not client:
        st.stop()
    
    # Sidebar for settings
    with st.sidebar:
        st.header("Translation Settings")
        
        source_language = st.selectbox(
            "Source Language",
            ["auto-detect", "English", "Spanish", "French", "German", "Italian", 
             "Portuguese", "Chinese", "Japanese", "Korean", "Russian", "Arabic"],
            index=0
        )
        
        target_language = st.selectbox(
            "Target Language",
            ["Spanish", "French", "German", "Italian", "Portuguese", "English",
             "Chinese", "Japanese", "Korean", "Russian", "Arabic"],
            index=0
        )
        
        st.markdown("---")
        st.markdown("### About")
        st.markdown("This tool translates text in PowerPoint presentations using xAI's Grok API.")
        st.markdown("Upload a .pptx file and select your target language to get started.")
    
    # Main content area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        uploaded_file = st.file_uploader(
            "Upload PowerPoint Presentation",
            type=["pptx"],
            help="Upload a .pptx file to translate"
        )
    
    with col2:
        if uploaded_file:
            st.info(f"📄 **File:** {uploaded_file.name}")
            st.info(f"📊 **Size:** {uploaded_file.size / 1024:.2f} KB")
    
    if uploaded_file is not None:
        if st.button("🚀 Translate Presentation", type="primary", use_container_width=True):
            with st.spinner("Translating your presentation..."):
                try:
                    # Load the presentation
                    prs = Presentation(BytesIO(uploaded_file.read()))
                    
                    # Show progress
                    st.info(f"Found {len(prs.slides)} slides to translate")
                    progress_bar = st.progress(0)
                    
                    # Translate the presentation
                    translated_prs = translate_presentation(
                        prs, client, target_language, source_language, progress_bar
                    )
                    
                    # Save translated presentation to BytesIO
                    output = BytesIO()
                    translated_prs.save(output)
                    output.seek(0)
                    
                    # Success message
                    st.success("✅ Translation completed successfully!")
                    
                    # Download button
                    original_name = uploaded_file.name.rsplit('.', 1)[0]
                    download_name = f"{original_name}_{target_language.lower()}.pptx"
                    
                    st.download_button(
                        label="📥 Download Translated Presentation",
                        data=output,
                        file_name=download_name,
                        mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        type="primary",
                        use_container_width=True
                    )
                    
                except Exception as e:
                    st.error(f"❌ Error processing presentation: {str(e)}")
    else:
        # Show instructions when no file is uploaded
        st.markdown("---")
        st.markdown("### 📋 Instructions")
        st.markdown("""
        1. **Upload** your PowerPoint presentation (.pptx file)
        2. **Select** source and target languages in the sidebar
        3. **Click** the translate button
        4. **Download** your translated presentation
        
        #### Supported Features:
        - ✅ Text in slides
        - ✅ Text in shapes
        - ✅ Text in tables
        - ✅ Multiple slides
        - ✅ Preserves formatting
        
        #### Note:
        - Images and embedded objects are not translated
        - The original formatting and layout are preserved
        """)

if __name__ == "__main__":
    main()
