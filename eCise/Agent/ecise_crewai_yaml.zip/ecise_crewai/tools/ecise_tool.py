from __future__ import annotations
from typing import Optional
import os, json, pathlib, random, requests
from collections import defaultdict
from pydantic import BaseModel, Field

try:
    from crewai_tools import BaseTool
except Exception:
    class BaseTool:
        name: str = "eCise Workout Generator"
        description: str = "Generates workout plans"
        args_schema = None
        def __init__(self, *args, **kwargs): pass
        def _run(self, **kwargs): raise NotImplementedError

DATA_URL = os.getenv("DATA_URL", "https://raw.githubusercontent.com/rod-trent/JunkDrawer/main/eCise/exercises_enriched_v2.json")
CACHE_PATH = pathlib.Path(os.getenv("CACHE_PATH", "./exercises_cache.json"))
META_PATH = pathlib.Path(os.getenv("META_PATH", "./exercises_cache.meta.json"))

FALLBACK = {
    "Chest":[{"name":"Flat Barbell Bench Press","description":"Lie on a flat bench holding a barbell. Lower to chest; press back up.","youtube_link":"https://www.youtube.com/watch?v=rT7DgCr-3pg"},
             {"name":"Push-Ups","description":"Plank position; lower chest near floor; push back up.","youtube_link":"https://www.youtube.com/watch?v=IODxDxX7oi4"}],
    "Back":[{"name":"Pull-Ups","description":"Hang from bar; pull until chin passes bar; lower with control.","youtube_link":"https://www.youtube.com/watch?v=eGo4IYlbE5g"}],
    "Legs":[{"name":"Barbell Squats","description":"Bar on back; squat to parallel; stand tall.","youtube_link":"https://www.youtube.com/watch?v=Dy28eq2PjcY"}],
    "Arms":[{"name":"Barbell Curls","description":"Underhand grip; curl to chest; lower slowly.","youtube_link":"https://www.youtube.com/watch?v=kwG2ipFRgfo"}],
    "Core":[{"name":"Plank","description":"Forearms + toes; body straight; hold.","youtube_link":"https://www.youtube.com/watch?v=pSHjTRCQxIw"}]
}

def _read_json(p: pathlib.Path):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None

def _write_json(p: pathlib.Path, data):
    try:
        p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False

def _conditional_headers():
    meta = _read_json(META_PATH)
    if not isinstance(meta, dict):
        return {}
    h = {}
    if "ETag" in meta: h["If-None-Match"] = meta["ETag"]
    if "Last-Modified" in meta: h["If-Modified-Since"] = meta["Last-Modified"]
    return h

def _save_cache(data, headers):
    if not isinstance(data, dict) or not data: return
    _write_json(CACHE_PATH, data)
    meta = {}
    if "ETag" in headers: meta["ETag"] = headers["ETag"]
    if "Last-Modified" in headers: meta["Last-Modified"] = headers["Last-Modified"]
    if meta: _write_json(META_PATH, meta)

def _normalize(raw):
    if isinstance(raw, dict):
        return {k: v for k, v in raw.items() if isinstance(v, list)}
    if isinstance(raw, list):
        keys = ["group","muscle_group","muscleGroup","category","bodypart","body_part"]
        buckets = defaultdict(list)
        for item in raw:
            if not isinstance(item, dict): continue
            g = None
            for k in keys:
                if k in item and item[k]:
                    g = str(item[k]); break
            buckets[g or "Misc"].append(item)
        return dict(buckets)
    return {}

def _generate(data: dict, mode: str, value: int):
    groups = list(data.keys())
    if not groups:
        return []

    if mode == "by_time":
        time_per = 10
        target = max(len(groups), value // time_per)
    else:
        target = max(1, value)

    workout = []
    if target < len(groups):
        picks = random.sample(groups, target)
        workout = [random.choice(data[g]) for g in picks if data[g]]
    else:
        workout = [random.choice(data[g]) for g in groups if data[g]]
        while len(workout) < target:
            g = random.choice(groups)
            if data[g]:
                workout.append(random.choice(data[g]))
    random.shuffle(workout)
    return workout

def _fmt(v):
    if v is None or v == "": return "N/A"
    if isinstance(v, list):
        if v and isinstance(v[0], dict):
            keys = ["name","muscle","label","title"]
            parts = []
            for d in v:
                if not isinstance(d, dict): parts.append(str(d)); continue
                chosen = None
                for k in keys:
                    if k in d and d[k]:
                        chosen = d[k]; break
                parts.append(str(chosen) if chosen is not None else json.dumps(d, ensure_ascii=False))
            return ", ".join(parts)
        return ", ".join(str(x) for x in v)
    if isinstance(v, dict):
        return json.dumps(v, ensure_ascii=False)
    return str(v)

def _render_markdown(workout):
    lines = []
    lines.append("# Your Custom Workout Routine")
    lines.append("")
    lines.append("_Perform 3 sets of 8–12 reps for each exercise unless otherwise specified._")
    lines.append("")
    if not workout:
        lines.append("> No exercises available.")
        return "\n".join(lines)

    for idx, ex in enumerate(workout, 1):
        name = ex.get("name", "Unknown Exercise")
        desc = ex.get("how_to") or ex.get("description") or "No description available."
        video = ex.get("youtube_link") or ex.get("video") or "N/A"
        equipment = ex.get("equipment")
        primary = ex.get("primary_muscles")
        secondary = ex.get("secondary_muscles")
        how_to = ex.get("how_to")
        difficulty = ex.get("difficulty")
        reps = ex.get("recommended_rep_scheme")
        injuries = ex.get("injury_considerations")

        lines.append(f"## {idx}. {name}")
        lines.append("")
        lines.append(f"- **Description:** {_fmt(desc)}")
        lines.append(f"- **YouTube/Video:** {_fmt(video)}")
        if equipment is not None:
            lines.append(f"- **Equipment:** {_fmt(equipment)}")
        if primary is not None:
            lines.append(f"- **Primary Muscles:** {_fmt(primary)}")
        if secondary is not None:
            lines.append(f"- **Secondary Muscles:** {_fmt(secondary)}")
        if how_to is not None and how_to != desc:
            lines.append(f"- **How To:** {_fmt(how_to)}")
        if difficulty is not None:
            lines.append(f"- **Difficulty:** {_fmt(difficulty)}")
        if reps is not None:
            lines.append(f"- **Recommended Rep Scheme:** {_fmt(reps)}")
        if injuries is not None:
            lines.append(f"- **Injury Considerations:** {_fmt(injuries)}")
        lines.append("")
    return "\n".join(lines)

class ECiseInput(BaseModel):
    mode: str = Field(description="Either 'by_exercises' or 'by_time'")
    value: int = Field(description="If mode=by_exercises -> number of exercises; if mode=by_time -> minutes")
    refresh: bool = Field(default=False, description="If true, bypass cache and force fresh download.")

class ECiseTool(BaseTool):
    name: str = "eCise Workout Generator"
    description: str = "Generates a Markdown workout plan using live/cached exercise data from GitHub."
    args_schema = ECiseInput

    def _run(self, mode: str, value: int, refresh: bool = False) -> str:
        data = None
        if refresh:
            try:
                r = requests.get(DATA_URL, timeout=10)
                r.raise_for_status()
                data = _normalize(r.json())
                if data: _save_cache(data, r.headers)
            except Exception:
                pass
        if data is None:
            try:
                headers = _conditional_headers()
                r = requests.get(DATA_URL, headers=headers, timeout=10)
                if r.status_code == 304:
                    data = _read_json(CACHE_PATH)
                else:
                    r.raise_for_status()
                    data = _normalize(r.json())
                    if data: _save_cache(data, r.headers)
            except Exception:
                data = _read_json(CACHE_PATH)
        if not data:
            data = FALLBACK

        workout = _generate(data, mode, int(value))
        md = _render_markdown(workout)
        return md
